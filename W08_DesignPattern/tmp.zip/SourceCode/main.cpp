#include "BrickBreaker.h"

Ball* Ball::instance = nullptr;

int main()
{
    Ball* b1 = Ball::getInstance();
    Ball* b2 = Ball::getInstance();

    std::cout << "Bai 1...........\nCreating 2 ball pointers, get instance and print out their addresses:\nb1: "; b1->printAddress(); std::cout << "\nb2: "; b2->printAddress(); std::cout << "\n";
    b1->deleteInstance();
    std::cout << "Call delete instance on 1 ball and print out their addresses:\nb1: "; b1->printAddress(); std::cout << "\nb2: "; b2->printAddress(); std::cout << "\n";
    return 0;
}