#include "Fraction.h"
#include "Array.h"
#include "StringToInteger.h"


int main()
{
    std::cout << "Bai 1......... \n" << "Try to set a fraction denominator to 0: \n";
    Fraction f;
    try 
    {
        f.setValue(1, 0);
    }
    catch (DividedByZeroException& ex)
    {
        std::cout << ex.what() << "\n";
    }
    std::cout << "Bai 2......... \n" << "Try to access the element with index number 7 in an array that has a capacity of 4: \n";
    Array a(4);
    try
    {
        int tmp = a.getValueAt(7);
        std::cout << tmp << "\n";
    }
    catch(IndexOutOfRangeException& ex)
    {
        std::cout << ex.what() << '\n';
    }
    std::cout << "Bai 4......... \n" << "Try to convert string one-two-three to integer: \n";
    try 
    {
        stringToInt("one-two-three");
    }
    catch(IntegerFormatException& ex)
    {
        std::cout << ex.what() << "\n";
    }



    return 0;
}