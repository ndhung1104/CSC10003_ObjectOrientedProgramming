class Fraction
{
    int numerator;
    int denominator;

public:
    void setValue();
    void printOnScreen();
    Fraction addFraction(Fraction a);
    Fraction subtractFraction(Fraction a);
    Fraction multiplyFraction(Fraction a);
    Fraction divideFraction(Fraction a);
};
