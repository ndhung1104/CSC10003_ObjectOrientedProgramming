class Student
{
    double mathGrade;
    double englishGrade;
    double programmingGrade;

public:
    void inputGrade();
    void outputAverageGrade();
    void isFullyExcelence();
};